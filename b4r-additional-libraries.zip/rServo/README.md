#rServo

Servo motor library

Further information: https://www.b4x.com/search?product=B4R&query=servo

B4R: https://www.b4x.com/b4r.html